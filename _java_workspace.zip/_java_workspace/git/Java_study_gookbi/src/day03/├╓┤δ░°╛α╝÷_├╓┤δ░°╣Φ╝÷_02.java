package day03;

public class 최대공약수_최대공배수_02 {

	public static void main(String[] args) {
		
	}

}
 