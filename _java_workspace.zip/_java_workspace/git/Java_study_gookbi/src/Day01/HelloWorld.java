package Day01;

public class HelloWorld {

	public static void main(String[] args) {
		/* print() : 줄바꿈이 없이 출력
		 * println() : 줄바꿈이 있는 출력
		 * printf() : 형식을 가지는 출력
		 * */
		System.out.println("Hello, World~!!!");
		System.out.println(1234);
		
		int num1;
		int num2, num3, num4;
		num1 = 123;
		
		System.out.println(num1);
	}

}
