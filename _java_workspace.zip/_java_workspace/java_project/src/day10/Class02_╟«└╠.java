package day10;

public class Class02_풀이 {

	public static void main(String[] args) {
		
//		Car c = new Car("Spark", "2013", "Gray");
		
	}
	
}

//class Car{
//	private boolean power;
//	private int speed;
//	private String name;
//	private String year;
//	private String color;
//
//	public Car(String name, String year, String color) {
//		this.name = name;
//		this.year = year;
//		this.color = color;
//	}
//	
//	public void powerOn() {
//		power = true;
//		System.out.println("전원이 켜졌습니다.");
//	}
//	
//	public void powerOff() {
//		power = false;
//		System.out.println("전원이 꺼졌습니다.");
//	}
//	
//	public void speedUp() {
//		speed++;
//	}
//	
//	public void speedDown() {
//		speed--;
//	}
//
//	public boolean isPower() {
//		return power;
//	}
//
//	public void setPower(boolean power) {
//		this.power = power;
//	}
//
//	public int getSpeed() {
//		return speed;
//	}
//
//	public void setSpeed(int speed) {
//		this.speed = speed;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getYear() {
//		return year;
//	}
//
//	public void setYear(String year) {
//		this.year = year;
//	}
//
//	public String getColor() {
//		return color;
//	}
//
//	public void setColor(String color) {
//		this.color = color;
//	}
//	
//	
