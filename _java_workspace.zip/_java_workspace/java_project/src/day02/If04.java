package day02;

public class If04 {

	public static void main(String[] args) {
		// if문
		
		int num = 12;
		
		if(num < 10) {
			System.out.println(num + "은 10보다 작습니다.");
		} else if (num == 10) {
			System.out.println(num + "은 10입니다.");
		} else {
			System.out.println(num + "은 10보다 큽니다.");
		}
		
		
		
	}

}
