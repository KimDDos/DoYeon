package day01;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World~!!!");
//		ㄴ 콘솔에 출력하기 위한 메서드임
//		중괄호에 의해 메모리에 입력, 삭제하는 기준으로 가비지 컬렉터가 관리를 하기 시작함
		// 한줄 주석 -> ctrl + /
		/*  다행 주석처리임  */
//		println() : 줄바꿈이 있는 출력
//		print() :줄바꿈이 없는 출
//		printf() :형식을 가지는 출력 (C언어에서 주로 사용)

		
		
		int num1;
		int num2, num3, num4;
		num1 = 123;
		System.out.println(num1);
		
		
	}

}
